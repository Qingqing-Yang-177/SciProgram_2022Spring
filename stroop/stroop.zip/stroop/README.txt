STROOP Task 

This task is made for Introduction to Scientific Programming, NYU.


Trial
32 trials (16-congruent; 16-incongruent)


Important Variables
infoType - trial type
thisWord - stimulus word displayed
thisColor - stimulus ink color
condition - congruent (thisColor==thisWord) and incongruent (thisColor!=thisWord)
corrAns - key press associated with correct response
participant - uid
key_resp.keys - recorded key press
key_resp.rt - key press rt
trials.thisN - trial number